

    <?php echo e($response); ?>


<?php /**PATH D:\xampp\htdocs\BatukApp\batukapp\resources\views/prova/index.blade.php ENDPATH**/ ?>